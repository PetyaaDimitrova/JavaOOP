package restaurant.repositories.interfaces;

import restaurant.entities.tables.interfaces.Table;

import java.util.Collection;

public class TableRepositoryImpl implements TableRepository<Table>{
    @Override
    public Collection<Table> getAllEntities() {
        return null;
    }

    @Override
    public void add(Table entity) {

    }

    @Override
    public Table byNumber(int number) {
        return null;
    }
}
