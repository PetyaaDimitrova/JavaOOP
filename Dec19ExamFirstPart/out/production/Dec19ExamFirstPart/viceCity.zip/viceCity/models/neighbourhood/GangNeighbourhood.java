package viceCity.models.neighbourhood;

import viceCity.models.guns.Gun;
import viceCity.models.players.Player;

import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Deque;
import java.util.List;
import java.util.stream.Collectors;

public class GangNeighbourhood implements Neighbourhood {
    @Override
    public void action(Player mainPlayer, Collection<Player> civilPlayers) {
      /*  Collection<Player> counterTerroristList = players.stream().filter(p -> p instanceof CounterTerrorist)
                .collect(Collectors.toList());
        Collection<Player> terroristList = players.stream().filter(p -> p instanceof Terrorist)
                .collect(Collectors.toList());

        while (counterTerroristList.stream().anyMatch(Player::isAlive) && terroristList.stream().anyMatch(Player::isAlive)) {
            for (Player terrorist : terroristList) {
                for (Player counterTerrorist : counterTerroristList) {
                    counterTerrorist.takeDamage(terrorist.getGun().fire());
                }
            }
            counterTerroristList = counterTerroristList.stream().filter(Player::isAlive).collect(Collectors.toList());

            for (Player counterTerrorist : counterTerroristList) {
                for (Player terrorist : terroristList) {
                    terrorist.takeDamage(counterTerrorist.getGun().fire());
                }
            }

            terroristList = terroristList.stream().filter(Player::isAlive).collect(Collectors.toList());


        }
        return terroristList.stream().anyMatch(Player::isAlive) ? OutputMessages.TERRORIST_WINS : OutputMessages.COUNTER_TERRORIST_WINS;
  */  }




}
