package main.java.glacialExpedition.models.mission;

import main.java.glacialExpedition.models.explorers.Explorer;
import main.java.glacialExpedition.models.states.State;

import java.util.Collection;

public class MissionImpl implements  Mission{



    @Override
    public void explore(State state, Collection<Explorer> explorers) {

    }
}
