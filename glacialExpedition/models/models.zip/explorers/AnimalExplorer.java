package main.java.glacialExpedition.models.explorers;

public class AnimalExplorer extends BaseExplorer{
    private static final double ENERGY = 40.0;
    public AnimalExplorer(String name) {
        super(name, ENERGY);
    }
}
